const form = document.getElementById("financeForm");
const exitBtn = document.getElementById("exitBtn");

form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const rtype = document.getElementById("rtype").value;
    const amount = parseFloat(document.getElementById("amount").value);
    const category = document.getElementById("category").value;
    const date = document.getElementById("date").value;
    const note = document.getElementById("note").value;

    const record = `${rtype},${amount},${category},${date},${note}`;
    await fetch("/save", { method: "POST", body: record });
    location.reload();
});

function deleteRecord(index) {
    fetch(`/delete?${index}`).then(() => location.reload());
}

exitBtn.addEventListener("click", () => {
    fetch("/exit").then(() => alert("Server stopped"));
});
