use std::fs::{self, OpenOptions};
use std::io::Read;
use std::io::Write;
use tiny_http::{Server, Response, Request};
use std::path::Path;
use std::sync::{Arc, Mutex};
use std::process;

fn main() {
    let server = Server::http("127.0.0.1:8081").unwrap();
    let running = Arc::new(Mutex::new(true));
    let r = running.clone();

    println!("🚀 Server running at http://127.0.0.1:8081");

    for request in server.incoming_requests() {
        if !*r.lock().unwrap() {
            break;
        }
        handle_request(request, r.clone());
    }
}

fn handle_request(mut request: Request, running: Arc<Mutex<bool>>) {
    let url = request.url().to_string();

    if url == "/" {
        let template = fs::read_to_string("static/index.html")
            .unwrap_or_else(|_| "<h1>Error loading index.html</h1>".to_string());
        let records = load_records();
        // build rows and compute totals
        let mut display = String::new();
        let mut total_income: f64 = 0.0;
        let mut total_expense: f64 = 0.0;
        let mut total_salary: f64 = 0.0;
        for (i, r) in records.iter().enumerate() {
            let rtype = &r.0;
            let amount = r.1;
            let category = &r.2;
            if rtype.eq_ignore_ascii_case("Income") {
                total_income += amount;
                if category.eq_ignore_ascii_case("Salary") {
                    total_salary += amount;
                }
            } else {
                total_expense += amount;
            }
            display.push_str(&format!(
                "<tr><td>{}</td><td>{:.2}</td><td>{}</td><td>{}</td><td>{}</td>\
                 <td><button onclick='deleteRecord({})'>Delete</button></td></tr>", 
                r.0, r.1, r.2, r.3, r.4, i
            ));
        }
        let savings = total_income - total_expense;
        let html = template.replace("{{records}}", &display)
            .replace("{{total_income}}", &format!("{:.2}", total_income))
            .replace("{{total_expense}}", &format!("{:.2}", total_expense))
            .replace("{{savings}}", &format!("{:.2}", savings))
            .replace("{{salary_total}}", &format!("{:.2}", total_salary));
        let response = Response::from_string(html)
            .with_header(tiny_http::Header::from_bytes(&b"Content-Type"[..], &b"text/html"[..]).unwrap());
        request.respond(response).unwrap();
    } else if url == "/app.js" {
        let js = fs::read_to_string("static/app.js").unwrap_or_default();
        let response = Response::from_string(js)
            .with_header(tiny_http::Header::from_bytes(&b"Content-Type"[..], &b"application/javascript"[..]).unwrap());
        request.respond(response).unwrap();
    } else if url == "/style.css" {
        let css = fs::read_to_string("static/style.css").unwrap_or_default();
        let response = Response::from_string(css)
            .with_header(tiny_http::Header::from_bytes(&b"Content-Type"[..], &b"text/css"[..]).unwrap());
        request.respond(response).unwrap();
    } else if url.starts_with("/save") {
        let mut data = String::new();
        request.as_reader().read_to_string(&mut data).unwrap();
        save_to_csv("data.csv", &data);
        let response = Response::from_string("✅ Data Saved Successfully");
        request.respond(response).unwrap();
    } else if url.starts_with("/delete") {
        let query = url.split('?').nth(1).unwrap_or("");
        if let Ok(index) = query.parse::<usize>() {
            delete_record(index);
        }
        let response = Response::from_string("Deleted");
        request.respond(response).unwrap();
    } else if url == "/exit" {
        *running.lock().unwrap() = false;
        let response = Response::from_string("Server stopped");
        request.respond(response).unwrap();
        println!("🛑 Server exited by user.");
        process::exit(0);
    } else {
        let response = Response::from_string("404 Not Found").with_status_code(404);
        request.respond(response).unwrap();
    }
}

fn save_to_csv(filename: &str, record: &str) {
    if !Path::new(filename).exists() {
        let mut f = fs::File::create(filename).unwrap();
        writeln!(f, "rtype,amount,category,date,note").unwrap();
    }
    let mut w = OpenOptions::new().append(true).open(filename).unwrap();
    // sanitize newlines
    let rec = record.replace("\n", " ").replace("\r", " ");
    writeln!(w, "{}", rec).unwrap();
}

fn load_records() -> Vec<(String, f64, String, String, String)> {
    if !Path::new("data.csv").exists() {
        return vec![];
    }
    let content = fs::read_to_string("data.csv").unwrap_or_default();
    content
        .lines()
        .skip(1)
        .map(|line| {
            let parts: Vec<&str> = line.split(',').collect();
            let amt = parts.get(1).and_then(|s| s.parse::<f64>().ok()).unwrap_or(0.0);
            (
                parts.get(0).unwrap_or(&"").to_string(),
                amt,
                parts.get(2).unwrap_or(&"").to_string(),
                parts.get(3).unwrap_or(&"").to_string(),
                parts.get(4).unwrap_or(&"").to_string(),
            )
        })
        .collect()
}

fn delete_record(index: usize) {
    let mut records = load_records();
    if index < records.len() {
        records.remove(index);
    }
    let mut f = fs::File::create("data.csv").unwrap();
    writeln!(f, "rtype,amount,category,date,note").unwrap();
    for r in records {
        writeln!(f, "{},{},{},{},{}", r.0, r.1, r.2, r.3, r.4).unwrap();
    }
}
